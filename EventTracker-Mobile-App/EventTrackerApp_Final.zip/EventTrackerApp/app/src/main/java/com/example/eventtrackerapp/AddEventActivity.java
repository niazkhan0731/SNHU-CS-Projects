package com.example.eventtrackerapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddEventActivity extends AppCompatActivity {

    private EditText nameInput, dateInput, timeInput;
    private Button saveButton;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        dbHelper = new DatabaseHelper(this);

        nameInput = findViewById(R.id.eventNameInput);
        dateInput = findViewById(R.id.eventDateInput);
        timeInput = findViewById(R.id.eventTimeInput);
        saveButton = findViewById(R.id.saveEventButton);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = nameInput.getText().toString().trim();
                String date = dateInput.getText().toString().trim();
                String time = timeInput.getText().toString().trim();

                if (name.isEmpty() || date.isEmpty() || time.isEmpty()) {
                    Toast.makeText(AddEventActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                } else {
                    boolean success = dbHelper.addEvent(name, date, time);
                    if (success) {
                        Toast.makeText(AddEventActivity.this, "Event added", Toast.LENGTH_SHORT).show();
                        finish(); // Go back to MainActivity
                    } else {
                        Toast.makeText(AddEventActivity.this, "Failed to add event", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
