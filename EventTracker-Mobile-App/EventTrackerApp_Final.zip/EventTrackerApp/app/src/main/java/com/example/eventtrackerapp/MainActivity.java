package com.example.eventtrackerapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private GridView gridView;
    private ArrayList<String> eventList;
    private ArrayAdapter<String> adapter;
    private Button addEventButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);
        gridView = findViewById(R.id.eventGridView);
        addEventButton = findViewById(R.id.addEventButton);
        eventList = new ArrayList<>();

        loadEvents();

        gridView.setOnItemClickListener((adapterView, view, position, id) -> {
            String selected = eventList.get(position);
            Toast.makeText(MainActivity.this, "Clicked: " + selected, Toast.LENGTH_SHORT).show();
        });

        addEventButton.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, AddEventActivity.class)));
    }

    private void loadEvents() {
        Cursor cursor = dbHelper.getAllEvents();
        eventList.clear();

        if (cursor.moveToFirst()) {
            do {
                String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));
                String time = cursor.getString(cursor.getColumnIndexOrThrow("time"));
                eventList.add(name + "\n" + date + " " + time);
            } while (cursor.moveToNext());
        }

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, eventList);
        gridView.setAdapter(adapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadEvents();
    }
}
